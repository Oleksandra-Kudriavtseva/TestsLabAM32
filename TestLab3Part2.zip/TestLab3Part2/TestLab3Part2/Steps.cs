﻿using Newtonsoft.Json.Linq;
using RestSharp;
using TechTalk.SpecFlow;


namespace TestLab3Part2
{
    [Binding]
    public sealed class Steps
    {
        private const string BaseUrl = "https://potterapi-fedeperin.vercel.app/en";
        private RestClient client;
        private RestResponse response;

        [Given(@"'BaseURL' API endpoint")]
        public void CreateRestClient()
        {
            client = new RestClient(BaseUrl);
        }

        [When(@"I send a GET request to ""/houses""")]
        public void CheckHouses()
        {
            var request = new RestRequest("/houses", Method.Get);
            response = client.Execute(request);
        }

        [Then(@"the response status code should be 200 for read all houses")]
        public void CheckHousesStatusCode()
        {
            Assert.AreEqual(200, (int)response.StatusCode, $"Expected status code 200, but got {(int)response.StatusCode}");
        }

        [Then(@"the response body should contain a list of houses")]
        public void CheckHousesResponse()
        {
            var content = response.Content;
            var houses = JArray.Parse(content);
            Assert.IsTrue(houses.Count > 0, "The list of houses is empty");
        }

        [When(@"I send a GET request to ""/houses/\?index"" with a valid index")]
        public void CheckHouseByValidIndex()
        {
            var validIndex = 0;
            var request = new RestRequest($"/houses/?index={validIndex}", Method.Get);
            response = client.Execute(request);
        }

        [Then(@"the response status code should be 200")]
        public void CheckHouseByValidIndexStatusCode()
        {
            Assert.AreEqual(200, (int)response.StatusCode, $"Expected status code 200, but got {(int)response.StatusCode}");
        }

        [Then(@"the response body should contain details about house with this index")]
        public void CheckHouseDetailsResponse()
        {
            var content = response.Content;
            var house = JObject.Parse(content);
            Assert.IsTrue(house.ContainsKey("house"), "House does not contain 'name' field");
        }

        [When(@"I send a GET request to ""/houses/\?index"" with an invalid index")]
        public void CheckHouseByInvalidIndex()
        {
            var invalidIndex = 9999;
            var request = new RestRequest($"/houses/?index={invalidIndex}", Method.Get);
            response = client.Execute(request);
        }

        [Then(@"the response status code should be 404")]
        public void CheckHouseInvalidIndexStatusCode()
        {
            Assert.AreEqual(404, (int)response.StatusCode, $"Expected status code 404, but got {(int)response.StatusCode}");
        }

        [Then(@"the response body should contain error:Invalid Index")]
        public void CheckHouseInvalidIndexResponse()
        {
            var content = response.Content;
            var responseBody = JObject.Parse(content);
            Assert.IsTrue(responseBody.ContainsKey("error"), "Response does not contain 'error' key");
            Assert.AreEqual("Invalid Index", responseBody["error"].ToString(), "Expected error message 'Invalid Index', but got something else");
        }

        [When(@"I send a GET request to ""/characters""")]
        public void CheckCharacters()
        {
            var request = new RestRequest("/characters", Method.Get);
            response = client.Execute(request);
        }

        [Then(@"the response status code should be 200 for read all characters")]
        public void CheckCharactersStatusCode()
        {
            Assert.AreEqual(200, (int)response.StatusCode, $"Expected status code 200, but got {(int)response.StatusCode}");
        }

        [Then(@"the response body should contain a list of characters")]
        public void CheckCharactersResponse()
        {
            var content = response.Content;
            var characters = JArray.Parse(content);
            Assert.IsTrue(characters.Count > 0, "The list of characters is empty");
        }

        [Then(@"each character's ""house"", if present, should match one of the ""house"" values from the houses list")]
        public void CheckCharactersHouseMatchHousesList()
        {
            var houseRequest = new RestRequest("/houses", Method.Get);
            var houseResponse = client.Execute(houseRequest);
            
            var houseContent = houseResponse.Content;
            var houses = JArray.Parse(houseContent);
            var houseNames = new HashSet<string>();
            foreach (var house in houses)
            {
                houseNames.Add(house["house"].ToString());
            }
            var content = response.Content;
            var characters = JArray.Parse(content);
            foreach (var character in characters)
            {
                if (character["house"] != null)
                {
                    var characterHouse = character["house"].ToString();
                    Assert.IsTrue(houseNames.Contains(characterHouse), $"Character's house '{characterHouse}' is not in the list of valid houses");
                }
            }
        }


        [When(@"I send a GET request to ""/books""")]
        public void CheckBooks()
        {
            var request = new RestRequest("/books", Method.Get);
            response = client.Execute(request);
        }

        [Then(@"the response status code should be 200 for read all books")]
        public void CheckBooksStatusCode()
        {
            Assert.AreEqual(200, (int)response.StatusCode, $"Expected status code 200, but got {(int)response.StatusCode}");
        }

        [Then(@"the response body should contain a list of books")]
        public void CheckBooksResponse()
        {
            var content = response.Content;
            var books = JArray.Parse(content);
            Assert.IsTrue(books.Count > 0, "The list of books is empty");
        }

        [When(@"I send a GET request to ""/books/\?search""")]
        public void SendGetRequestToWithSearch()
        {
            var request = new RestRequest($"/books/?search={"Stone"}", Method.Get);
            response = client.Execute(request);
        }


        [Then(@"the response body should contain all books with searched elements")]
        public void CheckBooksSearchResults()
        {
            var content = response.Content;
            var books = JArray.Parse(content);
            Assert.IsTrue(books.Count > 0, "No search results found");

            foreach (var book in books)
            {
                var title = book["title"]?.ToString() ?? string.Empty;
                Assert.IsTrue(title.Contains("Stone"), $"Book description does not contain the search term 'Jun': {title}");
            }
        }

        [When(@"I send a GET request to ""/spells""")]
        public void SendGetRequestToSpells()
        {
            var request = new RestRequest("/spells", Method.Get);
            response = client.Execute(request);
        }

        
        [Then(@"the response status code should be 200 for read all spells")]
        public void CheckSpellsStatusCode()
        {
            Assert.AreEqual(200, (int)response.StatusCode, $"Expected status code 200, but got {(int)response.StatusCode}");
        }

        [Then(@"the response body should contain a list of spells")]
        public void CheckSpellsResponse()
        {
            var content = response.Content;
            var spells = JArray.Parse(content);
            Assert.IsTrue(spells.Count > 0, "The list of spells is empty");
        }


        [When(@"I send a GET request to ""/spells/\?max"" with the number of spells I want to receive")]
        public void SendGetRequestToSpellsWithMax()
        {
            int max = 2;
            var request = new RestRequest($"/spells/?max={max}", Method.Get);
            response = client.Execute(request);
        }



        [Then(@"the response body should contain the number of spells")]
        public void CheckNumberOfSpells()
        {
            int max = 2;
            var content = response.Content;
            var spells = JArray.Parse(content);
            Assert.AreEqual(max, spells.Count, $"Expected {max} spells, but got {spells.Count}");
        }

        
        [When(@"I send a GET request to ""/spells/\?max&page"" with the max number and page number")]
        public void SendGetRequestToSpellsWithPagination()
        {
            int max = 2;
            int page = 2;
            var request = new RestRequest($"/spells/?max={max}&page={page}", Method.Get);
            response = client.Execute(request);

        }

      
        [Then(@"the response body should contain the number of spells on the page")]
        public void CheckNumberOfSpellsOnPage()
        {
            int max = 2;
            int page = 2;
            var content = response.Content;
            var spells = JArray.Parse(content);
            Assert.IsTrue(spells.Count <= max, $"Expected number of spells on page {page} to be at most {max}, but got {spells.Count}");
        }


    }
}

