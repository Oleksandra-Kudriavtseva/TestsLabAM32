﻿using CalcClassBr;
using ErrorLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        public static long MAXINT = 2147483647;
        public static long MININT = -2147483648;


        [TestMethod]
        public void DivMAXDivident()
        {

            long result = CalcClass.Div(MAXINT, 1);
            Assert.AreEqual(MAXINT, result);
        }
        [TestMethod]
        public void DivMAXDivisor()
        {

            long result = CalcClass.Div(1, MAXINT);
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void DivMAXDividentAndDivisor()
        {

            long result = CalcClass.Div(MAXINT, MAXINT);
            Assert.AreEqual(1, result);
        }


        [TestMethod]
        public void DivLessThanMAXDivident()
        {

            long result = CalcClass.Div(MAXINT - 1, 1);
            Assert.AreEqual(MAXINT - 1, result);
        }
        [TestMethod]
        public void DivLessThanMAXDivisor()
        {

            long result = CalcClass.Div(1, MAXINT - 1);
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void DivLessThanMAXDividentAndDisor()
        {

            long result = CalcClass.Div(MAXINT - 1, MAXINT - 1);
            Assert.AreEqual(1, result);
        }


        [TestMethod]
        public void DivMINDivident()
        {

            long result = CalcClass.Div(MININT, 1);
            Assert.AreEqual(MININT, result);
        }
        [TestMethod]
        public void DivMINDivisor()
        {

            long result = CalcClass.Div(1, MININT);
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void DivMINDividentAndDivisor()
        {

            long result = CalcClass.Div(MININT, MININT);
            Assert.AreEqual(1, result);
        }


        [TestMethod]
        public void DivLessThanMINDivident()
        {

            long result = CalcClass.Div(MININT + 1, 1);
            Assert.AreEqual(MININT + 1, result);
        }
        [TestMethod]
        public void DivLessThanMINDivisor()
        {

            long result = CalcClass.Div(1, MININT + 1);
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public void DivLessThanMINDividentAndDivisor()
        {

            long result = CalcClass.Div(MININT + 1, MININT + 1);
            Assert.AreEqual(1, result);
        }


        [TestMethod]

        public void DivByZero()
        {
            try
            {
                CalcClass.Div(1, 0);
                Assert.Fail("Division by zero should throw exception");
            }
            catch (DivideByZeroException e)
            {
                Assert.AreEqual(e.Message, ErrorsExpression.ERROR_09);
            }
        }

        [TestMethod]
        public void DivOverMAXDivident()
        {
            try
            {
                CalcClass.Div(MAXINT + 1, 1);
                Assert.Fail("Argument MAXINT+1 should throw exception");
            }
            catch (ArgumentOutOfRangeException e)
            {
                Assert.AreEqual(e.ParamName, ErrorsExpression.ERROR_06);
            }
        }

        [TestMethod]
        public void DivOverMAXDivisor()
        {
            try
            {
                CalcClass.Div(1, MAXINT + 1);
                Assert.Fail("Argument MAXINT+1 should throw exception");
            }
            catch (ArgumentOutOfRangeException e)
            {
                Assert.AreEqual(e.ParamName, ErrorsExpression.ERROR_06);
            }
        }
        [TestMethod]

        public void DivOverMINDivident()
        {
            try
            {
                CalcClass.Div(MININT - 1, 1);
                Assert.Fail("Argument MININT-1 should throw exception");
            }
            catch (ArgumentOutOfRangeException e)
            {
                Assert.AreEqual(e.ParamName, ErrorsExpression.ERROR_06);
            }
        }

        [TestMethod]
        public void DivOverMINDivisor()
        {
            try
            {
                CalcClass.Div(1, MININT - 1);
                Assert.Fail("Argument MININT - 1 should throw exception");
            }
            catch (ArgumentOutOfRangeException e)
            {
                Assert.AreEqual(e.ParamName, ErrorsExpression.ERROR_06);
            }
        }
        [TestMethod]
        public void DivMinusDivident()
        {

            long result = CalcClass.Div(-1, 1);
            Assert.AreEqual(-1, result);
        }
        [TestMethod]
        public void DivMinusDivisor()
        {

            long result = CalcClass.Div(1, -1);
            Assert.AreEqual(-1, result);
        }



        public TestContext TestContext { get; set; }
        [TestMethod]
        [DataSource("System.Data.SqlClient", @"Data Source=.\SqlExpress;Initial Catalog=TestDatabase;Integrated Security=True;Pooling=False", "TestData", DataAccessMethod.Sequential)]
        public void TestDivBD()
        {

            int Divided = (int)TestContext.DataRow["Divided"];
            int Divisor = (int)TestContext.DataRow["Divisor"];
            int expected = (int)TestContext.DataRow["Result"];
            int actual = CalcClass.Div(Divided, Divisor);
            Assert.AreEqual(expected, actual);


        }

    }
}
