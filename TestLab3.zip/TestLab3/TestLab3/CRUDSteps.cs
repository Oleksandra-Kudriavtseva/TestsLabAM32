﻿using System;
using System.ComponentModel;
using Newtonsoft.Json.Linq;
using RestSharp;
using TechTalk.SpecFlow;

namespace TestLab3
{
    [Binding]
    public class CRUDSteps
    {
        private const string BaseUrl = "https://restful-booker.herokuapp.com";
        private RestClient client;
        public RestResponse CreateResponse;
        public JObject CreateJsonResponse;
        private RestResponse UpdateResponse;
        private RestResponse DeleteResponse;
        public int CreatedId;

        private string GetBasicAuthHeader(string username, string password)
        {
            var authString = $"{username}:{password}";
            var authBase64 = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(authString));
            return $"Basic {authBase64}";
        }

        RestResponse CreateBooking(string fn, string ln, int tp, bool dp, string ci, string co, string an)
        {
            var bookingData = new
            {
                firstname = fn,
                lastname = ln,
                totalprice = tp,
                depositpaid = dp,
                bookingdates = new
                {
                    checkin = ci,
                    checkout = co
                },
                additionalneeds = an
            };

            var request = new RestRequest("/booking", Method.Post);
            request.AddHeader("Accept", "application/json");
            request.AddJsonBody(bookingData);
            var response = client.Execute(request);
            return response;
        }

        RestResponse ReadBooking(int id)
        {
            var request = new RestRequest("/booking/" + id, Method.Get);
            request.AddHeader("Accept", "application/json");
            var response = client.Execute(request);
            return response;
        }

        RestResponse UpdateBooking(int id, string fn, string ln, int tp, bool dp, string ci, string co, string an)
        {
            var bookingData = new
            {
                firstname = fn,
                lastname = ln,
                totalprice = tp,
                depositpaid = dp,
                bookingdates = new
                {
                    checkin = ci,
                    checkout = co
                },
                additionalneeds = an
            };

            var request = new RestRequest($"/booking/{id}", Method.Put);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", GetBasicAuthHeader("admin", "password123"));
            request.AddJsonBody(bookingData);
            var response = client.Execute(request);
            return response;
        }

        RestResponse DeleteBooking(int id)
        {
            var request = new RestRequest("/booking/" + id, Method.Delete);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", GetBasicAuthHeader("admin", "password123"));
            var response = client.Execute(request);
            return response;

        }

        [Given(@"'BaseURL' API endpoint")]
        public void CreateRestClient()
        {
            client = new RestClient(BaseUrl);
        }

        [When(@"I create booking")]
        public void TestCreate()
        {
            CreateResponse = CreateBooking("Alex", "Doe", 100, true, "2024-12-10", "2024-12-20", "Cleaning");
        }

        [Then(@"RestClient return status code 200 after creation")]
        public void CheckStatusCode()
        {
            Assert.AreEqual(200, (int)CreateResponse.StatusCode, "Status code is not 200 OK");
            Console.WriteLine(CreateResponse.Content);
        }

        [Then(@"Response contains bookingid")]
        public void CheckBookingId()
        {
            CreateJsonResponse = JObject.Parse(CreateResponse.Content);
            CreatedId = Int32.Parse(CreateJsonResponse.GetValue("bookingid").ToString());
            Assert.IsNotNull(CreatedId);
        }

        [Then(@"Response contains booking info")]
        public void CheckBookingInfo()
        {
            var ReadResponse = ReadBooking(CreatedId);
            Console.WriteLine(ReadResponse.Content);
            var jsonRead = JObject.Parse(ReadResponse.Content);
        }

        [When(@"I update the booking")]
        public void UpdateTheBooking()
        {
            UpdateResponse = UpdateBooking(CreatedId, "Josh", "Smith", 90, true, "2024-11-30", "2024-12-10", "Lunch");
        }

        [Then(@"RestClient return status code 200 after update")]
        public void UpdateCheckStatusCode()
        {
            Assert.AreEqual(200, (int)UpdateResponse.StatusCode, "Status code is not 200 OK");
            Console.WriteLine(UpdateResponse.Content);
        }
        
        [Then(@"Response contains updated booking info")]
        public void CheckUpdatedBookingInfo()
        {
            var ReadResponse = ReadBooking(CreatedId);
            Console.WriteLine(ReadResponse.Content);
            var jsonRead = JObject.Parse(ReadResponse.Content);
        }

        [When(@"I delete the booking")]
        public void DeleteTheBooking()
        {
            DeleteResponse = DeleteBooking(CreatedId);
            Console.WriteLine(DeleteResponse.Content);
            
        }

        [Then(@"RestClient return status code 201 after deleting")]
        public void DeleteCheckStatusCode()
        {
            Assert.AreEqual(201, (int)DeleteResponse.StatusCode, "Status code is not 201 OK");
            Console.WriteLine(DeleteResponse.Content);
        }
        
        [Then(@"Responce contain nothing")]
        public void CheckDeletedBookingInfo()
        {
            var ReadResponse = ReadBooking(CreatedId);
            Console.WriteLine(ReadResponse.Content);
            Assert.IsTrue(string.IsNullOrEmpty(ReadResponse.Content) || ReadResponse.Content.Contains("Not Found"),"Response content is not empty or does not indicate 'Not Found'.");
            Assert.AreEqual(404, (int)ReadResponse.StatusCode, "Status code is not 404 Not Found");

        }
    }
}
